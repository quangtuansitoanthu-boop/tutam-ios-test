import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import enCopy from '../../../src/lib/i18n/copying-interface-en.json';
import { nextGhostTraceText, reconcileGhostTyping } from '../../../src/lib/domain/practice/copying-ghost-format';

const pageSource = readFileSync(new URL('../../../src/routes/tu-tap/chep-kinh/+page.svelte', import.meta.url), 'utf8');

describe('scripture copying Android/iOS fixes', () => {
  it('handles iOS speech voice guidance separately instead of showing Android settings message', () => {
    expect(pageSource).toContain("nativePlatform() === 'android'");
    expect(pageSource).toContain('Cài đặt iPhone → Trợ năng → Nội dung được đọc');
    expect((enCopy as Record<string, string>)['Cài đặt iPhone → Trợ năng → Nội dung được đọc']).toBeTruthy();
    expect((enCopy as Record<string, string>)['Hãy mở Cài đặt iPhone → Trợ năng → Nội dung được đọc để tải giọng tiếng Việt.']).toBeTruthy();
  });

  it('applies horizontal safe-area insets for landscape notch/Dynamic Island on .copy-writing', () => {
    expect(pageSource).toContain('env(safe-area-inset-left');
    expect(pageSource).toContain('env(safe-area-inset-right');
  });

  it('does not render duplicate editor-font-controls alongside compact-editor-display', () => {
    expect(pageSource).not.toContain('class="source-font-controls editor-font-controls"');
  });

  it('guards mobile options save button with restarting and composing and keeps options message sticky', () => {
    expect(pageSource).toMatch(/class="mobile-account-actions"[\s\S]*?disabled=\{loading \|\| !draft \|\| networkBusy \|\| restarting \|\| composing\}/);
    expect(pageSource).toContain('class="options-message"');
  });

  it.each([
    ['Trước Phật đài.', 'truwowcs phataj daif', 'Trước Phật đài'],
    ['Hương thường ấm.', 'huwowng thuwowngf aams', 'Hương thường ấm'],
    ['Được nguyện.', 'duwowcdj nguyenej', 'Được nguyện'],
    ['Đà chân bổn.', 'dadf chana bonor', 'Đà chân bổn'],
  ])('accepts free-order Vietnamese Telex modifiers and double-horn ươ words (%s)', (canonical, keys, expected) => {
    let text = '';
    let state: Parameters<typeof reconcileGhostTyping>[3];
    for (const key of keys) {
      const result = reconcileGhostTyping(canonical, text, { incoming: key, inputType: 'insertText' }, state);
      expect(result.mismatch, `key "${key}" after "${text}"`).toBe(false);
      text = result.text;
      state = result.state;
    }
    expect(text).toBe(expected);
  });

  it('accepts a trailing tone/mark key after a multi-char unaccented replacement chunk on iOS', () => {
    const chunk = reconcileGhostTyping('Phật tâm.', '', { incoming: 'phat', inputType: 'insertReplacementText' });
    expect(chunk.text).toBe('Phật');
    const circumflex = reconcileGhostTyping('Phật tâm.', chunk.text, { incoming: 'a', inputType: 'insertText' }, chunk.state);
    expect(circumflex.mismatch).toBe(false);
    const tone = reconcileGhostTyping('Phật tâm.', circumflex.text, { incoming: 'j', inputType: 'insertText' }, circumflex.state);
    expect(tone.mismatch).toBe(false);
    // Repeating tone again must still report mismatch
    const duplicate = reconcileGhostTyping('Phật tâm.', tone.text, { incoming: 'j', inputType: 'insertText' }, tone.state);
    expect(duplicate.mismatch).toBe(true);
  });

  it('treats mobile contenteditable NBSP (\\u00a0) identically to ASCII space at punctuation and line breaks', () => {
    const prose = 'Tu rị tu rị, ma ha.\nNguyện cầu.';
    expect(nextGhostTraceText(prose, 'Tu rị tu rị', { key: '\u00a0' })).toBe('Tu rị tu rị, ');
    expect(nextGhostTraceText(prose, 'Tu rị tu rị, ma ha', { key: '\u00a0' })).toBe('Tu rị tu rị, ma ha.\n');
  });

  it('uses a top-right close X button and 2 action buttons in the leave-copying dialog', () => {
    const dialogMatch = pageSource.match(/\{#if leaveChoiceOpen\}([\s\S]*?)\{\/if\}/);
    expect(dialogMatch).not.toBeNull();
    const dialogMarkup = dialogMatch![1];
    expect(dialogMarkup).toContain('copy-save-dialog-close');
    expect(dialogMarkup).toContain("aria-label={localizeUi('Ở lại')}");
    const actionsMatch = dialogMarkup.match(/class="copy-save-dialog-actions"([\s\S]*?)<\/div>/);
    expect(actionsMatch).not.toBeNull();
    expect(actionsMatch![1].match(/<button\b/g)).toHaveLength(2);
  });

  it('shows a dedicated modal dialog for save success and save error feedback', () => {
    expect(pageSource).toContain('{#if saveFeedback}');
    expect(pageSource).toContain('copy-save-feedback-title');
    expect(pageSource).toContain("localizeUi('Đã lưu bản chép')");
    expect(pageSource).toContain("localizeUi('Chưa thể lưu bản chép')");
    expect((enCopy as Record<string, string>)['Đã lưu bản chép']).toBeTruthy();
    expect((enCopy as Record<string, string>)['Chưa thể lưu bản chép']).toBeTruthy();
  });
});
